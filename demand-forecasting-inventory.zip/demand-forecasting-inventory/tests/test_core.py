import math

import numpy as np
import pandas as pd
import pytest

from src.data import generate_sample_data, validate_sales_data
from src.forecast import backtest, forecast_future, prepare_sku_frame
from src.inventory import eoq, inventory_plan, reorder_point, safety_stock


@pytest.fixture(scope="module")
def frame():
    df = validate_sales_data(generate_sample_data(end="2024-12-31"))
    return prepare_sku_frame(df, df["sku"].iloc[0])


def test_eoq_textbook_value():
    # D=1000, S=50, H=2 -> sqrt(2*1000*50/2) = 223.6
    assert eoq(1000, 50, 10, 0.2) == pytest.approx(223.607, rel=1e-3)


def test_safety_stock_and_rop():
    ss = safety_stock(10, 4, 0.95)
    assert ss == pytest.approx(1.6449 * 10 * 2, rel=1e-3)
    assert reorder_point(50, 4, ss) == pytest.approx(200 + ss)


def test_higher_service_level_needs_more_stock():
    assert safety_stock(10, 7, 0.99) > safety_stock(10, 7, 0.90)


def test_inventory_plan_keys():
    plan = inventory_plan(100, 15, 7, 0.95, 500, 40, 0.2)
    assert plan["reorder_point"] > 700 and plan["eoq"] > 0 and plan["orders_per_year"] > 0


def test_validate_rejects_missing_columns():
    with pytest.raises(ValueError):
        validate_sales_data(pd.DataFrame({"date": ["2024-01-01"], "sku": ["A"]}))


def test_frame_is_continuous_daily(frame):
    assert (frame["date"].diff().dropna() == pd.Timedelta(days=1)).all()


def test_backtest_beats_moving_average(frame):
    res = backtest(frame, horizon=28)
    wape = res["metrics"].set_index("Model")["WAPE %"]
    assert wape["Gradient Boosting (ML)"] < wape["28-day Moving Avg"]
    assert res["sigma"] > 0


def test_forecast_shape_and_non_negative(frame):
    fc = forecast_future(frame, 30)
    assert len(fc) == 30 and (fc["forecast"] >= 0).all()
    assert fc["date"].min() == frame["date"].max() + pd.Timedelta(days=1)


def test_short_history_raises():
    df = validate_sales_data(generate_sample_data(end="2023-03-01"))
    short = prepare_sku_frame(df, df["sku"].iloc[0])
    with pytest.raises(ValueError):
        backtest(short, horizon=28)
