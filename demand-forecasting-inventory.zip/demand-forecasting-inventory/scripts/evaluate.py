"""Backtest every SKU and save results/metrics.csv (used for the README table)."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd

from src.data import load_sample_data
from src.forecast import backtest, prepare_sku_frame

HORIZON = 28

if __name__ == "__main__":
    df = load_sample_data()
    rows = []
    for sku in sorted(df["sku"].unique()):
        res = backtest(prepare_sku_frame(df, sku), horizon=HORIZON)
        for _, r in res["metrics"].iterrows():
            rows.append({"sku": sku, **r.to_dict()})
    out = pd.DataFrame(rows)
    Path("results").mkdir(exist_ok=True)
    out.to_csv("results/metrics.csv", index=False)

    summary = out.groupby("Model")[["MAE", "RMSE", "WAPE %"]].mean().round(2).sort_values("WAPE %")
    print(f"Average over {df['sku'].nunique()} SKUs, {HORIZON}-day horizon, rolling-origin backtest\n")
    print(summary.to_string())
    summary.to_csv("results/summary.csv")
